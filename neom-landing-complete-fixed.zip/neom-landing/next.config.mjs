/** @type {import("next").NextConfig} */
const nextConfig = {
  images: {
    unoptimized: true, // Tắt tối ưu hóa hình ảnh của Next.js
  },
};

export default nextConfig;


